//
//  main.cpp
//  Kalah
//
//  Created by Yunfan Jin on 10/20/14.
//  Copyright (c) 2014 yunfan.jin. All rights reserved.
//

#include <iostream>
#include "Gamer.h"

int main(int argc, const char * argv[]) {
    
    //test1();
    
    Gamer gamer;
    gamer.start();
    
    
    return 0;
}

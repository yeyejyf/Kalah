//
//  RunnablePlayer.h
//  Kalah
//
//  Created by Yunfan Jin on 10/20/14.
//  Copyright (c) 2014 yunfan.jin. All rights reserved.
//

#ifndef Kalah_RunnablePlayer_h
#define Kalah_RunnablePlayer_h

class RunnablePlayer{
    
public:
    
    virtual bool run() = 0;
};

#endif
